package models;

public class ElectronicProduct extends Product {
    private double power;

    public ElectronicProduct(String name, double price, String refernce, double power) {
        super(name, price, refernce);
        this.power = power;
    }

    public double getPower() {
        return power;
    }

    public void setPower(double power) {
        this.power = power;
    }

    @Override
    public String getDescription() {
        return "Electronic Product : " + getName() + " " + ",Price: " + getPrice() + ",Reference: " + getRefernce()
                + ",Power: " + getPower();
    }

}
