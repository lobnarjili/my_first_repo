package services;

import models.Product;

public interface Cart {

    // defaut
    // par defaut package private

    public void addProduct(Product product);

    public boolean removeProduct(Product product);

    public void displayProduct();

    public double total();

}
