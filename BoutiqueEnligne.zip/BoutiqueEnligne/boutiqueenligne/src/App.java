import models.BookProduct;
import models.ClothingProduct;
import models.ElectronicProduct;
import services.Cart;
import services.Order;
import services.OrderPromo;

public class App {
    public static void main(String[] args) throws Exception {
        // System.out.println("Hello, World!");

        // Cart cart = new OrderPromo(5, 0);
        Cart cart = new Order(5, 0);
        cart.addProduct(new ElectronicProduct("Printer", 755.0, "1524", 8.0));
        cart.addProduct(new ClothingProduct("Pants", 39.99, "7568", "Large"));
        cart.addProduct(new BookProduct("Java for Begginner ", 55.99, "10568", "Jason Stone"));
        System.out.println("Prodcut list ");
        cart.displayProduct();
        System.out.println("Total: $ " + cart.total());
        cart.addProduct(new ElectronicProduct("scanner", 800.0, "1524", 7.0));
        System.out.println("Prodcut list ");
        cart.displayProduct();

        cart.removeProduct(new BookProduct("Java for Begginner ", 55.99, "10568", "Jason Stone"));
        System.out.println(" New Prodcut list ");
        cart.displayProduct();

        cart.addProduct(new ElectronicProduct("Printer", 755.0, "1424", 8.0));
        cart.addProduct(new ClothingProduct("Pants", 39.99, "7668", "Large"));
        cart.addProduct(new BookProduct("Java for Begginner ", 55.99, "9568", "Jason Stone"));
        cart.addProduct(new BookProduct("Java  ", 55.99, "11168", "Jason Stone"));

        System.out.println(" Neww Prodcut list ");
        cart.displayProduct();

    }
}
