package services;

import models.Product;

public class OrderPromo implements Cart {

    public Product[] products;
    private int size;

    /*
     * public Order(Product[] products, int size) {
     * this.products = products;
     * this.size = size;
     * }
     */

    public OrderPromo(int capacity, int size) {
        this.products = new Product[capacity];
        this.size = 0;
    }

    @Override
    public void addProduct(Product product) {
        if (size < products.length) {
            if (findProduct(product) == -1) {
                int index = 0;
                while (index < products.length && products[index] != null) {
                    index++;

                }
                products[index] = product;
                size++;

            } else {
                System.out.println("Cannot add product with same reference!");

            }
        } else {
            System.out.println("cannot add more products . Order is full ");
        }

    }

    @Override
    public boolean removeProduct(Product product) {
        int index = findProduct(product);
        if (index != -1) {
            products[index] = null;
            size--;
            return true;
        } else {
            System.out.println("Product not found in the order");
            return false;

        }

    }

    @Override
    public void displayProduct() {
        if (size == 0) {
            System.out.println("No product ");
        } else
            for (Product product : products) {
                if (product != null)
                    System.out.println(product.getDescription());

            }
    }

    @Override
    public double total() {
        double sum = 0.0;
        for (Product product : products) {
            if (product != null) {
                sum = sum + product.getPrice();
                // sum+= pproduct.getPrice();

            }

        }
        double promo = (sum * 20) / 100;
        return promo;

    }

    private int findProduct(Product product) {
        for (int i = 0; i < products.length; i++) {
            if (products[i] != null && products[i].getRefernce().equals(product.getRefernce())) {
                return i;
            }
            ;
        }
        return -1;
    }

}
