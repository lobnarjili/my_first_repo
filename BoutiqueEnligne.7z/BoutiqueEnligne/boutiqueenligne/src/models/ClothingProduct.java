package models;

public class ClothingProduct extends Product {

    private String size;

    public ClothingProduct(String name, double price, String refernce, String size) {
        super(name, price, refernce);
        this.size = size;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    @Override
    public String getDescription() {
        return "Clothing Product : " + getName() + " " + ",Price: " + getPrice() + ",Reference: " + getRefernce()
                + ",Size : " + getSize();
    }

}
