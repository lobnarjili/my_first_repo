package models;

public abstract class Product {
    private String name;
    private double price;
    private String refernce;

    public Product(String name, double price, String refernce) {
        this.name = name;
        this.price = price;
        this.refernce = refernce;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getRefernce() {
        return refernce;
    }

    public void setRefernce(String refernce) {
        this.refernce = refernce;
    }

    public abstract String getDescription();

}
