package models;

public class BookProduct extends Product {
    private String author;

    public BookProduct(String name, double price, String refernce, String author) {
        super(name, price, refernce);
        this.author = author;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    @Override
    public String getDescription() {
        return "Book Product : " + getName() + " " + ",Price: " + getPrice() + ",Reference: " + getRefernce()
                + ",Author: " + getAuthor();
    }

}
