public interface Cart {
// Declaration de l'interface cart 




        // Méthode abstraite ajoute un produit au panier,

        void addProduct(Product product);

         // Méthode abstraite  retire un produit du panier,
        boolean removeProduct(Product product);
        // Méthode abstraite affiche les produit du panier
        void displayProducts();  
        //  Méthode abstraite retourne le montant total des produits dans le panier.
        double total();

    
        
    


    
}