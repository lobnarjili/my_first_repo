
class Order implements Cart {
    private static final int Capacite_Max = 10;

    Product[] products;

    int size;

    public Order() {
        this.size = 0;
        // Constructeur qui initialise le tableau avec une capacité donnée

        this.products = new Product[Capacite_Max];

    }

    /*
     * Une méthode
     * nommée addProduct(Product product) qui ajoute un produit au tableau de
     * produits.
     * Si le tableau est plein, la méthode ne doit pas ajouter le produit
     */
    @Override
    public void addProduct(Product product) {
        if (size < Capacite_Max) {
            products[size++] = product;

          //  System.out.println(" New product list :");
            //System.out.println(product.getDescription());

        } 
        else if (size > Capacite_Max){

        System.out.println("Can't add again product  ");}
        
    }

    

    /*
     * Une méthode nommée removeProduct(Product product)
     * qui retire un produit du tableau de produits. Si le
     * produit n'est pas présent dans le tableau, la méthode retourne false
     */
    @Override
    public boolean removeProduct(Product product) {
        for (int i = 0; i < size; i++) {
            if (products[i].equals(product)) {
                // for (int j =i ;j<size-1; j++){
                products[i] = products[i + 1];
                // products[size -1]=null ;

               //  }
                size--;//product.getDescription().;
                   // if(product.get!= true)
                System.out.println(product.getClass().getName() + " deleted successfully");
                return true;
            }
        }
       

        System.out.println("Product not found in the order.");
        return false;

    }

    /*
     * Une méthode
     * nommée total() qui calcule le montant total des produits dans la commande en
     * additionnant le prix de chaque produit dans le tableau.
     */
    @Override
    public double total() {
        double total = 0;
        for (int i = 0; i < size; i++) {
            total = total + products[i].getPrice();
        }
        return total ;
    }

    /*
     * La classe doit également avoir une
     * méthode displayProducts() qui affiche les produits actuels dans la commande.
     */

    @Override
    public void displayProducts() {

        for (int i = 0; i < size; i++) {
            System.out.println(products[i].getDescription());
        }

    }
}

/*
 * public void supprimerElement(String elementASupprimer) {
 * int indexASupprimer = -1;
 * 
 * // Rechercher l'index de l'élément à supprimer
 * for (int i = 0; i < tableau.length; i++) {
 * if (tableau[i].equals(elementASupprimer)) {
 * indexASupprimer = i;
 * break;
 * }
 * }
 * 
 * // Si l'élément est trouvé, le supprimer du tableau
 * if (indexASupprimer != -1) {
 * tableau = Arrays.copyOfRange(tableau, 0, tableau.length - 1);
 * System.out.println("Élément supprimé : " + elementASupprimer);
 * } else {
 * System.out.println("Élément non trouvé : " + elementASupprimer);
 * }
 * }
 */
