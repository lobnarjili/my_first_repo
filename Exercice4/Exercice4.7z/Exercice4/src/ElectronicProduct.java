
    // Déclaration de la classe fille ElectronicProduct
 class ElectronicProduct extends Product {
    private double power;

    //constructeur 
    public ElectronicProduct(String name, double price, String reference, double power){
        super(name, price, reference);
        this.power = power;
    }

       // Méthode spécifique à ElectronicProduct
       public double getPower() {
        return power;
    }

    // Méthode spécifique à ElectronicProduct
    public void setPower(double power) {
        this.power = power;
    }
    //méthode nommée getDescription() qui renvoie une chaîne de caractères décrivant le produit électronique.
    
    public String getDescription(){
        return "Electronic Product :  Nom: " + getName() + ", Power: " + getPower()  + ", Prix: " + getPrice() + ", Référence: " + getReference();

    }

}
    

