public class App {
    public static void main(String[] args) throws Exception {
        ElectronicProduct electronicProduct = new ElectronicProduct("Printer ", 755.0, "1524", 8.0);
        ClothingProduct clothingProduct =new ClothingProduct("Pants", 39.99, "7568","Large");
        BookProduct bookProduct =new BookProduct("Java for Begginner ", 55.99, "7568", "Jason Stone");
        ElectronicProduct electronicProduct2 = new ElectronicProduct("Printer2 ", 555.0, "1824", 8.2);
        ElectronicProduct electronicProduct3 = new ElectronicProduct("Printer3 ", 455.0, "1924", 8.3);
        ClothingProduct clothingProduct2 =new ClothingProduct("Pants2", 29.99, "7468","Large");
        ClothingProduct clothingProduct3 =new ClothingProduct("Pants3", 19.99, "7368","Small");
        BookProduct bookProduct2 =new BookProduct("Git for Begginner ", 45.99, "7578", "Jason Jason");
        BookProduct bookProduct3 =new BookProduct("SpringBoot for Begginner ", 25.99, "1568", "Stone Stone");
        ElectronicProduct electronicProduct4 = new ElectronicProduct("Mac ", 7755.0, "1524", 8.0);
        ElectronicProduct electronicProduct5 = new ElectronicProduct("PC ", 3755.0, "1524", 8.0);









        Order order =new Order();
        System.out.println(" Product list :");

        order.addProduct(electronicProduct);
        order.addProduct(clothingProduct);
        order.addProduct(bookProduct);
        order.addProduct(electronicProduct2);
        order.addProduct(electronicProduct3);
        order.addProduct(clothingProduct2);
        order.addProduct(clothingProduct3);
        order.addProduct(bookProduct2);
        order.addProduct(bookProduct3);
        order.addProduct(electronicProduct4);
        order.addProduct(electronicProduct5);


        order.displayProducts();
        order.removeProduct(electronicProduct3);
        System.out.println("Total : $" + order.total());

        System.out.println(" New Product list :");
        order.displayProducts();


        

        //System.out.println("Hello, World!");
    }
}
