
    // Déclaration de la classe fille BookProduct
    class BookProduct extends Product {
 
        private String author;


        //constructeur 
   public BookProduct(String name, double price, String reference, String author){
       super(name, price, reference);
       this.author = author;
   }

   // GETTER ET SETTER pour author
   public String getAuthor(){
       return author;
   }
   public void setAuthor (String author) {
       this.author = author;
   }
    //méthode nommée getDescription() qui renvoie une chaîne de caractères décrivant le livre 
    @Override
    public String getDescription(){
        return "Book Product - Nom: " + getName() +  ", Prix: " + getPrice() + ", Référence: " + getReference() + ", Author: " + getAuthor() ;

    }

    // Declaration de l'interface cart 
    public interface Cart {
        // Méthode abstraite ajoute un produit au panier,

        void addProduct(Product product);

         // Méthode abstraite  retire un produit du panier,
        boolean removeProduct(Product product);
        // Méthode abstraite affiche les produit du panier
        void displayProducts();  
        //  Méthode abstraite retourne le montant total des produits dans le panier.
        double total();

    
        
    }
    
}
