
    // Déclaration de la classe fille ClothingProduct
    class ClothingProduct extends Product {
        private String size;


         //constructeur 
    public ClothingProduct(String name, double price, String reference, String size){
        super(name, price, reference);
        this.size = size;
    }

    public String getSize(){
        return size;
    }
    public void setSize (String size) {
        this.size = size;
    }
     //méthode nommée getDescription() qui renvoie une chaîne de caractères décrivant les vetements .
     @Override
     public String getDescription(){
         return "Clothing Product - Nom: " + getName()   + ", Prix: " + getPrice() + ", Référence: " + getReference()+ ", Size: " + getSize();
 
     }


    }

    

